
class DataIntegrityException(Exception):
    pass

class AuthenticationException(Exception):
    pass

class UnauthorizedException(Exception):
    pass
